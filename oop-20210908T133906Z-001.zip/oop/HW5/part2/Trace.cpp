#include "Trace.h"

int Trace::depth = -1;
